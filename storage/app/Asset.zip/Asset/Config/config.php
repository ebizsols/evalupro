<?php

return [
    'name' => 'Asset',
    'verification_required' => true,
    'envato_item_id' => 25830090,
    'parent_envato_id' => 23263417,
    'script_name' => 'worksuite-saas-asset',
    'setting' => \Modules\Asset\Entities\AssetSetting::class,
];
