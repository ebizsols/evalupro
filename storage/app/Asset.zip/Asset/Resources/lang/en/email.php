<?php

return array(
    'salaryStatus' =>
    array(
        'text' => 'Your salary slip is updated to status: ',
    )
);
