<?php

return array(
    'payroll' =>
    array(
        'menu' => 'Assets',
    )
);
