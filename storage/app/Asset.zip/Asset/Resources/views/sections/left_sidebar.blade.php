<li><a href="{{ route('admin.assets.index') }}" class="waves-effect"> <i class="fa fa-desktop"></i>
        <span class="hide-menu">@lang('asset::app.menu.asset')</span></a>
</li>

