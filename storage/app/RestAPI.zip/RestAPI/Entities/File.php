<?php namespace Modules\RestAPI\Entities;
   
use App\BaseModel;
use Illuminate\Database\Eloquent\Model;

class File extends BaseModel
{
    // region Properties

    protected $table = 'files';

    //endregion
}
