<?php

namespace Modules\RestAPI\Http\Controllers;

use App\ProjectCategory;

class ProjectCategoryController extends ApiBaseController
{
    protected $model = ProjectCategory::class;
}
